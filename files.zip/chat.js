// Fungsi pelayan Netlify untuk "Cikgu Anyam AI" (Google Gemini API).
// Kunci API disimpan sebagai pemboleh ubah persekitaran GEMINI_API_KEY, BUKAN dalam kod.

const SYSTEM_PROMPT = `Kamu ialah "Cikgu Anyam AI", pembantu mesra untuk murid Tahun 3 (umur sekitar 9 tahun) dalam subjek Pendidikan Seni Visual, Unit 10: Seni Anyaman Berzaman.

PERATURAN:
- Jawab dalam Bahasa Melayu yang mudah, ayat pendek, maksimum 4 ayat. Boleh guna 1-2 emoji.
- Hanya jawab tentang seni anyaman, mengkuang, kertas warna, teknik selang-seli 1:1 (atas-bawah), unsur seni (garisan, jalinan, rupa, warna), idea produk berfungsi (penanda buku, alas cawan, bekas kecil) dan warisan kraf Malaysia.
- Jika soalan di luar topik, tolak dengan lembut dan ajak murid bertanya tentang anyaman.
- Jangan minta atau simpan maklumat peribadi. Jika murid menaip maklumat peribadi, ingatkan dengan baik supaya tidak berkongsi.
- Untuk aktiviti menggunakan gunting atau alat tajam, ingatkan murid supaya minta bantuan atau kebenaran cikgu.
- Jangan dakwa kamu manusia. Jika tidak pasti, katakan dan galakkan murid bertanya kepada cikgu.
- Galakkan murid mencuba sendiri dengan nada positif.`;

const json = (statusCode, body) => ({
  statusCode,
  headers: { 'Content-Type': 'application/json; charset=utf-8' },
  body: JSON.stringify(body),
});

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Kaedah tidak dibenarkan' });
  if ((event.body || '').length > 6000) return json(413, { error: 'Mesej terlalu panjang' });

  const apiKey = process.env.GEMINI_API_KEY;
  const model = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
  if (!apiKey) return json(500, { error: 'Kunci API belum ditetapkan' });

  let incoming;
  try {
    incoming = JSON.parse(event.body || '{}').messages;
  } catch (e) {
    return json(400, { error: 'Format tidak sah' });
  }
  if (!Array.isArray(incoming) || incoming.length === 0) return json(400, { error: 'Tiada mesej' });

  // Bersihkan: maksimum 6 mesej terakhir, 300 aksara setiap satu, mesti bermula dengan "user"
  let msgs = incoming.slice(-6)
    .filter((m) => m && (m.role === 'user' || m.role === 'model') && typeof m.text === 'string')
    .map((m) => ({ role: m.role, text: m.text.slice(0, 300) }));
  while (msgs.length && msgs[0].role !== 'user') msgs.shift();
  if (msgs.length === 0 || msgs[msgs.length - 1].role !== 'user') return json(400, { error: 'Mesej tidak sah' });

  try {
    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
          contents: msgs.map((m) => ({ role: m.role, parts: [{ text: m.text }] })),
          generationConfig: { maxOutputTokens: 800, temperature: 0.6 },
        }),
      }
    );
    if (res.status === 429) return json(429, { error: 'Terlalu banyak soalan, cuba sebentar lagi' });
    if (!res.ok) return json(502, { error: 'Perkhidmatan AI tidak tersedia' });
    const data = await res.json();
    const reply = (data.candidates?.[0]?.content?.parts || []).map((p) => p.text || '').join('').trim();
    return json(200, { reply });
  } catch (e) {
    return json(502, { error: 'Perkhidmatan AI tidak tersedia' });
  }
};
